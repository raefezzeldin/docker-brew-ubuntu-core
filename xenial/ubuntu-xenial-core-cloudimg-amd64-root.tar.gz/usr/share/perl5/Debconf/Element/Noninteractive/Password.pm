#!/usr/bin/perl -w
# This file was preprocessed, do not edit!


package Debconf::Element::Noninteractive::Password;
use strict;
use base qw(Debconf::Element::Noninteractive);


1
